#ifndef __HARDWARE_TM4C123H_H_INCLUDED__
#define __HARDWARE_TM4C123H_H_INCLUDED__

void setupHardware(void);  // called once

void mainTOGGLE_LED(void);  // called to toggle the LED

#endif // __HARDWARE_TM4C123H_H_INCLUDED__